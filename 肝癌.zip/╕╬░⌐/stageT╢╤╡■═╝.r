rm(list = ls())
options(stringsAsFactors = F)
setwd("D:/R数据")
getwd()
library(Seurat)
library(ggplot2)
library(dplyr)
library(ggalluvial)
Ratio <- data3 %>%
  group_by(group, stage.T) %>%#分组
  summarise(n=n()) %>%
  mutate(relative_freq = n/sum(n))



Ratio=Ratio[,-4]
Ratio=Ratio[-10,]
Ratio=Ratio[-9,]
Ratio= as.numeric(Ratio)
library(reshape2)
Ratio[2,3]<-Ratio[2,3]+Ratio[3,3]+Ratio[4,3]
Ratio=Ratio[-c(3:4),]
Ratio[3,3]<-Ratio[3,3]+Ratio[4,3]+Ratio[5,3]
Ratio=Ratio[-c(4:5),]
Ratio[7,3]<-Ratio[7,3]+Ratio[8,3]
Ratio=Ratio[-8,]

Ratio<-Ratio %>%
  group_by(group) %>%
  mutate(Percentage=paste0(round(n/sum(n)*100,3)))
library(ggplot2)

library(RColorBrewer)

library(ggplot2)
p = ggplot( Ratio, aes( x = group, weight = as.numeric(Percentage), fill = stage.T))+
  geom_bar( position = "stack")+
  labs(x="", y = "Percentage") +
  scale_fill_manual(values=c("T1"="#a4cbec","T2" = "#69c2e3","T3" = "#7da2ce","T4" = "#1383c2"))
  # fill为修改图例标题


