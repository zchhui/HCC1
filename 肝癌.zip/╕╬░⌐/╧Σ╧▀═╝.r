rm(list = ls())
options(stringsAsFactors = F)
setwd("D:/R数据")
getwd()
data3<-read.table("data3.txt")
Bcell<-data3[,c(1,5)]
library(ggplot2)
library(ggpubr)
p=ggplot(Bcell, aes(x=group,y=B.cells.naive)) +     
  geom_boxplot(aes(fill=group))+
  
 scale_fill_manual(values=c("synergism"="#83c567","Non-synergistic" = "#27753b"))
p + ylim(0, 0.06)
compare_means(formula=B.cells.naive ~ group, Bcell, method = "wilcox.test", paired = FALSE,
              group.by = NULL, ref.group = NULL)
stat_compare_means(mapping = NULL, comparisons = NULL, hide.ns = FALSE,
                   label = NULL,  label.x = NULL, label.y = NULL)
compare_means(B.cells.naive ~ group, data = Bcell)
p + stat_compare_means()
# Change method
p + stat_compare_means(method = "t.test")
p + stat_compare_means(
                        label.x = 1.5, label.y = 0.2)
Tcell<-data3[,c(1,6)]
library(ggplot2)
q=ggplot(Tcell, aes(x=group,y=T.cells.CD8)) +     
  geom_boxplot(aes(fill=group))+
  scale_fill_manual(values=c("synergism"="#a4cbec","Non-synergistic" = "#7da2ce"))
q+ ylim(0, 0.075)
compare_means(formula=T.cells.CD8 ~ group, Tcell, method = "wilcox.test", paired = FALSE,
              group.by = NULL, ref.group = NULL)
stat_compare_means(mapping = NULL, comparisons = NULL, hide.ns = FALSE,
                   label = NULL,  label.x = NULL, label.y = NULL)
compare_means(T.cells.CD8 ~ group, data = Tcell)
q + stat_compare_means()
# Change method
q + stat_compare_means(method = "t.test")
q + stat_compare_means(
  label.x = 1.5, label.y = 0.2)

T.cells.CD4.memory.activated<-data3[,c(1,7)]
library(ggplot2)
b=ggplot(T.cells.CD4.memory.activated, aes(x=group,y=T.cells.CD4)) +     
  geom_boxplot(aes(fill=group))+
  scale_fill_manual(values=c("synergism"="#a4cbec","Non-synergistic" = "#7da2ce"))
b+ ylim(0, 0.01)
compare_means(formula=T.cells.CD4.memory.activated ~ group, Tcell, method = "wilcox.test", paired = FALSE,
              group.by = NULL, ref.group = NULL)
stat_compare_means(mapping = NULL, comparisons = NULL, hide.ns = FALSE,
                   label = NULL,  label.x = NULL, label.y = NULL)
compare_means(T.cells.CD4.memory.activated ~ group, data = Tcell)
b + stat_compare_means()
# Change method
b + stat_compare_means(method = "t.test")
b + stat_compare_means(
  label.x = 1.5, label.y = 0.2)

data3$Plasma.cells <- my[as.factor(substring(rownames(data3),1,15)),3]


Macrophages.M2<-data3[,c(1,8)]
library(ggplot2)
ggplot(Macrophages.M2, aes(x=group,y=Macrophages.M2)) +     
  geom_boxplot(aes(fill=group))+
  scale_fill_manual(values=c("synergism"="#a4cbec","Non-synergistic" = "#7da2ce"))

Plasma.cells<-data3[,c(1,9)]
library(ggplot2)
ggplot(Plasma.cells, aes(x=group,y=Plasma.cells)) +     
  geom_boxplot(aes(fill=group))+
  scale_fill_manual(values=c("synergism"="#a4cbec","Non-synergistic" = "#7da2ce"))
